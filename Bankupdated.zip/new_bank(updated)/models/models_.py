from services.account_serivce import BankService
# con,cursor = BankService.database() #from db we return con and cursor
# con, cursor = BankService.database()
class AccountService:
    def __init__(self, database):
        self.database = BankService
        self.con, self.cursor = self.database.connect_to_database(database)

        create_table_query = """
            CREATE TABLE IF NOT EXISTS bank_details (
                acc_no INT,
                name VARCHAR(255),
                age INT,
                contact INT,
                `add` INT,
                balance DOUBLE
            )
        """
        self.cursor.execute(create_table_query)
        self.con.commit()
        
        create_login_table_query = """
            CREATE TABLE IF NOT EXISTS bank_login (
                acc_no INT,
                password VARCHAR(255)
            )
        """
        self.cursor.execute(create_login_table_query)
        self.con.commit()
        
    def get_accounts(self):
        query = "select acc_no from bank_details"
        self.cursor.execute(query)
        accounts = [iter[0] for iter in self.cursor.fetchall()]
        self.con.commit()
        return accounts

    def get_password(self, acc_no):
        query = "select password from bank_details where acc_no = %s"
        self.cursor.execute(query, acc_no)
        row = self.cursor.fetchone()
        password = row[0]
        self.con.commit()
        return password

    def open_account(self, acc_no, name, age, contact, add, balance):
        query = "insert into bank_details values (%s,%s,%s,%s,%s,%s)"
        data  = (acc_no, name, age, contact, add, balance)
        self.cursor.execute(query, data) 
        self.con.commit()

    def get_account_details(self, acc_no):
        query = "select * from bank_details where acc_no = %s"
        self.cursor.execute(query, acc_no)
        details = self.cursor.fetchone()
        bank_account = {'acc_no':details[0], 'name':details[1], 'age':details[2] ,'contact_no':details[3],'address':details[4], 'balance':details[5]}
        self.con.commit()
        return bank_account

    def add_balance(self, acc_no, amount):
        query = "update bank_details set balance = balance+(%s) where acc_no = (%s)"
        data=(amount, acc_no)
        self.cursor.execute(query, data)
        self.con.commit()

    def debit_balance(self, acc_no, amount):
        query = "update bank_details set balance = balance-(%s) where acc_no = (%s)"
        data=(amount, acc_no)
        self.cursor.execute(query, data)
        self.con.commit()

    def delete_account(self, acc_no):
        query = "delete from bank_details where acc_no = %s"
        data = (acc_no)
        self.cursor.execute(query, data)
        self.con.commit()

    def delete_account_login(self, acc_no):
        query = "delete from bank_details where acc_no = %s"
        data = (acc_no)
        self.cursor.execute(query, data)
        self.con.commit()

    def withdraw(self, amount, acc_no):
        query ="UPDATE bank_details SET balance = balance - (%s) WHERE acc_no = (%s);"
        data=(amount, acc_no)
        self.cursor.execute(query, data)
        self.con.commit()
    
    def create_login(self,acc_no,password):
        query = "insert into bank_login values (%s,%s)"
        data = (acc_no,password)
        self.cursor.execute(query,data)
        self.con.commit()
       

