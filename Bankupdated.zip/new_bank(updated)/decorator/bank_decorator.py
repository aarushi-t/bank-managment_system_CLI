
from  models import models_ as model

# session = None



# def session_decorator(func):
#     def wrapper_func():
#         if session is None:
#             print("you must be logged in ")
#             return None
#         return func()
#     return wrapper_func


class SessionManager:
    def __init__(self):
        self.session = None

    def login(self):
        # implement login logic here
        self.session = True

    def logout(self):
        self.session = None

    def session_decorator(self, func):
        def wrapper_func(*args, **kwargs):
            if self.session is None:
                print("You must be logged in")
                return None
            return func(*args, **kwargs)
        return wrapper_func