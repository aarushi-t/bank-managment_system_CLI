
import random

from models import  models_ as model
from constants import contants as const
from services import account_serivce as service
from decorator import bank_decorator as decorator 


# account_service = service.BankService(database)
bank_service = service.BankService()  #instance of the BankService class
con, cursor = bank_service.connect_to_database()
account_service = service.BankService()

        
class BankAccount:
    # serive = model.AccountService()
    def __init__(self):
        self.accounts = {}  # dictionary to store account details
        self.session = None  # session variable to store logged-in account
        self.account_service = service.BankService() 
    
    def open_acc(self):
        name = input("Enter your name: ")
        age = int(input("Enter your age: "))
        
        database = self.account_service.connect_to_database()
        account_service = model.AccountService(database)

        if self.under_age(age):
            address = input("Enter your address: ")
            contact = int(input("Enter your contact: "))
            
            while True:
                acc_no = random.randint(10000, 99999)
                if not self.account_check(acc_no):
                    break

            self.accounts[acc_no] = {
                'name': name,
                'age': age,
                'contact': contact,
                'address': address,
                'balance': 0
            }
            
            password = input("Enter your password: ")
            account_service.create_login(acc_no, password)
        
            print("Your account number is:", acc_no)
            

    def close_account(self):
        acc_no = int(input("Enter your account number: "))
        if self.account_check(acc_no):
            del self.accounts[acc_no]
            self.session = None
        else:
            print("Account not found")

    def deposit(self):
        acc_no = int(input("Enter your account number: "))
        if self.account_check(acc_no):
            amount = float(input("Enter amount to deposit: "))
            self.accounts[acc_no]['balance'] += amount
            print("Deposit successful")
            return acc_no
        else:
            print("Account number not found")

    def show_balance(self):
        acc_no = int(input("Enter your account number: "))
        if self.account_check(acc_no):
            print(self.accounts[acc_no]['balance'])
        else:
            print("Account number not found")

    def login(self):
        acc_no = int(input("Enter your account number: "))
        if self.account_check(acc_no):
            password = input("Enter your password: ")
            if password == self.get_password(acc_no):
                self.session = [acc_no]
                print("You have logged in")
            else:
                print("Wrong password")
        else:
            print("Account not found")

    def acc_details(self):
        acc_no = int(input("Enter your account number: "))
        if acc_no in self.accounts:
            print(self.accounts[acc_no])
        else:
            print("Account not found")

    def withdraw(self):
        acc_no = int(input("Enter your account number: "))
        if self.account_check(acc_no):
            amount = int(input("Enter your amount: "))
            if self.accounts[acc_no]['balance'] >= amount:
                self.accounts[acc_no]['balance'] -= amount
                print("Your amount is withdrawn")
            else:
                print("Insufficient balance")
        else:
            print("Account not found")

    def logout(self):
        print("You have been logged out")
        self.session = None

    def under_age(self, age):
        # implement age check logic here
        if  age >= 18:
            return True
        else:
            return False
        
        

    def account_check(self, acc_no):
        return acc_no in self.accounts

    # def create_login(self, acc_no, password):
    #     # implement login creation logic here

    #     pass

    def get_password(self, acc_no):
        # implement password retrieval logic here
        pass