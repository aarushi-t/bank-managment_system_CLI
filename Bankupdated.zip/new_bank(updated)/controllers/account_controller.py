import random

from views import account_views as views
from models import  models_ as model
from constants import contants as const
from services import account_serivce as service
from decorator import bank_decorator as decorator 

def operations():
    bank_account = views.BankAccount() #instance of bank account
    is_running = True
    while is_running==True:

        print("1 for LOGIN")
        print("2 FOR OPEN ACCOUNT")
        print("3 FOR ACCOUNT DETAILS")
        print("4 FOR DEPOSIT")
        print("5 FOR LOG DETAILS")
        print("6 FOR SHOW BALANCE")
        print("7 FOR WITHDRAW")
        print("8 FOR LOGOUT")
        print("0 FOR QUIT")
        
        choice = int(input("Enter your choice: "))
        
        if choice == 1:
            bank_account.login()
        elif choice == 2:
            bank_account.open_acc()
        elif choice == 3:
            bank_account.acc_details()
        elif choice == 4:
            bank_account.deposit()
        # elif choice == 5:
        #     views.
        elif choice == 6:
            bank_account.show_balance()
        elif choice == 7:
            bank_account.withdraw()
        elif choice == 8:
            bank_account.logout()
        elif choice == 0:
            is_running = False
        else:
            print("Invalid choice. Please try again.")