
import pymysql

class BankService:
    def __init__(self):
        self.con, self.cursor = self.connect_to_database()

    def connect_to_database(self):
        con = pymysql.connect(host='localhost', user='root', password='root', db='bank_db')
        cursor = con.cursor()
        return con, cursor

    def under_age(self, age):
        return age >= 18

    def wrong_contact(self, contact):
        return contact <= 10

    def account_check(self, acc_no):
        return acc_no in self.get_acc()

    def balance_check(self, acc_no, amount):
        bank = self.acc_details(acc_no)
        return bank['balance'] >= amount

    def get_acc(self):
        # implement logic to retrieve accounts from database
        query = "SELECT * FROM bank_accounts"
        self.cursor.execute(query)
        accounts = self.cursor.fetchall()
        return accounts
    

    def acc_details(self, acc_no):
        # implement logic to retrieve account details from database
        
        query = "SELECT * FROM bank_accounts WHERE account_number = %s"
        self.cursor.execute(query, (acc_no,))
        account = self.cursor.fetchone()
        return account
    

